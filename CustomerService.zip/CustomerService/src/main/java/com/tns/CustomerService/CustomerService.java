package com.tns.CustomerService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



@SuppressWarnings("unused")
public class CustomerService {
	  @Autowired
	  private CustomerRepository repo;
		
		public void save(Customer employ)
		{
			repo.save(employ);
		}
		
		public List<Customer > getAllEmployee()
		{
			return repo.findAll();
		}
		
		public Customer  getEmployeeById(Integer id) 
		{
			return repo.findById(id).orElse(null);
		}
		
		public void deleteEmployee(Integer id)
		{
			repo.deleteById(id);
		}
		public void updateEmployee(Integer id , Customer updatedEmployee)
		{
			Customer  existingEmployee = repo.findById(id).orElse(null);
			if (existingEmployee != null)
			{
				existingEmployee.setId(updatedEmployee.getId());
				existingEmployee.setName(updatedEmployee.getName());
				existingEmployee.setAddress(updatedEmployee.getAddress());
				repo.save(existingEmployee);
			}
		}

		public List<Customer> listAll() {
			// TODO Auto-generated method stub
			return null;
		}
	  
}	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	 
